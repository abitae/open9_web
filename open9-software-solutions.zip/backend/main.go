
package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"sync"
	"time"
)

type Project struct {
	ID       int      `json:"id"`
	Title    string   `json:"title"`
	Category string   `json:"category"`
	Desc     string   `json:"desc"`
	Img      string   `json:"img"`
	Tech     []string `json:"tech"`
	Impact   string   `json:"impact"`
}

type Store struct {
	sync.RWMutex
	Projects []Project
}

var store = Store{
	Projects: []Project{
		{ID: 1, Title: "NexGen Fintech", Category: "Enterprise", Tech: []string{"Go", "React"}},
	},
}

func enableCORS(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
		if r.Method == "OPTIONS" {
			return
		}
		next.ServeHTTP(w, r)
	})
}

func main() {
	mux := http.NewServeMux()
	mux.HandleFunc("/api/projects", func(w http.ResponseWriter, r *http.Request) {
		store.RLock()
		json.NewEncoder(w).Encode(store.Projects)
		store.RUnlock()
	})

	fmt.Println("Server running on :8080")
	log.Fatal(http.ListenAndServe(":8080", enableCORS(mux)))
}
